// Classe para gerenciamento do checklist, incluindo modal e formatter

// Classe para gerenciamento do checklist customizado
class JirayaTemplateCustomizada {
  constructor() {
    this.inicializado = false;
  }

  inicializar() {
    if (this.inicializado) return;
    this.inicializado = true;
    if (typeof jirayalog === "function") {
      jirayalog("[Checklist] Módulo checklist customizado inicializado!");
    } else {
      console.log("[Checklist] Módulo checklist customizado inicializado!");
    }
  }

  abrirModalTemplateCustomizada(caminhoJson, aoFinalizar) {
    // Se o modal está minimizado, apenas maximiza e retorna
    if (document.getElementById("jiraya-modal-maximizar")) {
      window.JirayaTemplateCustomizada.maximizarModalTemplateCustomizada();
      return;
    }
    // Se já existe overlay/modal visível, não abre outro
    if (document.getElementById("overlay-checklist-customizado")) {
      return;
    }
    $.getJSON(caminhoJson, function (campos) {
      // Adiciona overlay escuro
      let overlay = $(
        '<div class="jiraya-overlay-base" id="overlay-checklist-customizado"></div>'
      );
      let html =
        '<div id="jiraya-modal-customizado" class="jiraya-modal-base jiraya-modal-customizado">';
      html += '<div class="jiraya-modal-header">';
      html += '<h2 class="jiraya-modal-titulo">📊 Checklist de qualidade</h2>';
      html +=
        '<a href="https://tdn.totvs.com/pages/viewpage.action?spaceKey=TVSSILC&title=Checklist+de+Qualidade+-+PDV" target="_blank" class="jiraya-modal-titulo">Documentação</a>';
      html += '<div class="jiraya-modal-header-actions">';
      html +=
        '<button type="button" class="jiraya-btn-outline-primario jiraya-modal-btn-minimizar" title="Minimizar" aria-label="Minimizar">&#8722;</button>';
      html +=
        '<button type="button" class="jiraya-btn-outline-primario jiraya-modal-btn-fechar" title="Fechar" aria-label="Fechar">&#10005;</button>';
      html += "</div>";
      html += "</div>";
      html += '<div class="jiraya-modal-body">';
      html += '<form id="form-checklist-customizado">';
      campos.forEach(function (campo) {
        html += `<div class="jiraya-modal-grupo-campo">`;
        html += `<label class="label-campo-checklist"><b>${campo.nome}</b></label>`;
        if (campo.tipo === "radio") {
          html += `<div class="opcoes-checklist-row">`;
          campo.itens.forEach(function (opcao, idx) {
            html += `<label class="opcao-radio-checklist"><input type="radio" name="${campo.id}" value="${opcao}"> ${opcao}</label>`;
          });
          html += `</div>`;
        } else if (campo.tipo === "checkbox") {
          html += `<div class="opcoes-checklist-row">`;
          campo.itens.forEach(function (opcao, idx) {
            html += `<label class="opcao-checkbox-checklist"><input type="checkbox" name="${campo.id}" value="${opcao}"> ${opcao}</label>`;
          });
          html += `</div>`;
          if (campo.outroCampo || campo.otherField) {
            html += `<input type="text" name="${campo.id}_outro" class="jiraya-modal-input" placeholder="Outra forma de pagamento"/>`;
          }
        } else if (campo.tipo === "textarea") {
          html += `<textarea name="${campo.id}" class="textarea-checklist" rows="2"></textarea>`;
          html += `<div class='jiraya-textarea-exemplo'><em>Exemplo: descreva aqui informações relevantes para este campo.</em></div>`;
        }
        html += `</div>`;
      });
      html += "</form>";
      html += "</div>";
      html += '<div class="botoes-jiraya-modal">';
      html +=
        '<button type="button" id="btn-cancelar-checklist" class="jiraya-btn-outline-primario">Cancelar</button>';
      html +=
        '<button type="submit" form="form-checklist-customizado" id="btn-criar-checklist" class="jiraya-btn-primario">Criar modelo</button>';
      html += "</div>";
      html += "</div>";
      overlay.append(html);
      $("body").append(overlay);
      // Botão fechar (X)
      $(document).on("click", ".jiraya-modal-btn-fechar", function () {
        $("#overlay-checklist-customizado").remove();
      });
      // Botão minimizar (-)
      $(document).on("click", ".jiraya-modal-btn-minimizar", function () {
        window.JirayaTemplateCustomizada.minimizarModalTemplateCustomizada();
      });
      // Botão maximizar (quando minimizado)
      $(document).on("click", "#jiraya-modal-maximizar", function () {
        window.JirayaTemplateCustomizada.maximizarModalTemplateCustomizada();
      });
      // Fecha modal ao clicar fora
      overlay.on("mousedown", function (e) {
        if (e.target === this) {
          $("#overlay-checklist-customizado").remove();
        }
      });

      $("#form-checklist-customizado").on("submit", function (e) {
        e.preventDefault();
        const respostas = {};
        campos.forEach(function (campo) {
          if (campo.tipo === "radio") {
            var valor = $(`input[name='${campo.id}']:checked`).val();
            if (valor !== undefined && valor !== null && valor !== "") {
              valor = "✅  " + valor;
            } else {
              valor = "Não se aplica";
            }
            respostas[campo.id] = valor;
          } else if (campo.tipo === "checkbox") {
            respostas[campo.id] = $(`input[name='${campo.id}']:checked`)
              .map(function () {
                return "✅  " + this.value + "";
              })
              .get();
            if (campo.outroCampo) {
              const outro = $(`input[name='${campo.id}_outro'`).val();
              if (outro) respostas[campo.id].push(outro);
            }
          } else if (campo.tipo === "textarea") {
            respostas[campo.id] = $(`textarea[name='${campo.id}']`).val();
          }
        });
        $("#overlay-checklist-customizado").remove();
        if (typeof aoFinalizar === "function") aoFinalizar(respostas, campos);
      });
    });
  }

  // Minimiza o modal para o canto inferior direito
  minimizarModalTemplateCustomizada() {
    const $modal = $("#jiraya-modal-customizado");
    const $overlay = $("#overlay-checklist-customizado");
    if ($modal.length && $overlay.length) {
      $modal.hide();
      $overlay.hide(); // Esconde overlay também
      if (!$("#jiraya-modal-minimizado").length) {
        // Pega o título do modal
        const titulo =
          $modal.find(".jiraya-modal-titulo").first().text() || "Checklist";
        const btn = $(
          '<button id="jiraya-modal-maximizar" title="Maximizar" class="jiraya-modal-maximizar">' +
            '<span class="jiraya-modal-maximizar-icone"><svg width="800px" height="800px" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" id="maximize" class="icon glyph"><path d="M10.71,14.71,5.41,20H10a1,1,0,0,1,0,2H4a2,2,0,0,1-1.38-.56l0,0s0,0,0,0A2,2,0,0,1,2,20V14a1,1,0,0,1,2,0v4.59l5.29-5.3a1,1,0,0,1,1.42,1.42ZM21.44,2.62s0,0,0,0l0,0A2,2,0,0,0,20,2H14a1,1,0,0,0,0,2h4.59l-5.3,5.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0L20,5.41V10a1,1,0,0,0,2,0V4A2,2,0,0,0,21.44,2.62Z" style="fill:#231f20"></path></svg></span>' +
            '<span class="jiraya-modal-titulo jiraya-modal-maximizar-titulo">' +
            titulo +
            "</span>" +
            "</button>"
        );
        $("body").append(btn);
      }
    }
  }

  // Maximiza o modal de volta ao centro (escopo global)
  maximizarModalTemplateCustomizada() {
    const $modal = $("#jiraya-modal-customizado");
    const $overlay = $("#overlay-checklist-customizado");
    if ($modal.length && $overlay.length) {
      $modal.show();
      $overlay.show(); // Mostra overlay novamente
      $("#jiraya-modal-maximizar").remove();
    }
  }

  gerarTemplateCustomizada(respostas, campos) {
    let template = "";
    campos.forEach(function (campo) {
      let valor = respostas[campo.id];
      let conteudo = "";
      if (Array.isArray(valor)) {
        conteudo = valor.length ? valor.join("\n") : "Não se aplica";
      } else {
        conteudo = valor && valor.trim() ? valor : "Não se aplica";
      }
      template += `{panel:title=${campo.nome}}\n${conteudo}\n{panel}\n\n`;
    });
    return template;
  }
}

// Expõe globalmente
window.JirayaTemplateCustomizada = new JirayaTemplateCustomizada();
