/**
 * Carrega e inicializa o módulo de checklist
 */
function carregarModuloTemplateCustomizada(elemento) {
  jirayalog("Checklist app detectado, carregando módulo específico");

  // Verifica se o script já foi carregado
  if (window.JirayaTemplateCustomizada && window.JirayaTemplateCustomizada.initialized) {
    jirayalog("Módulo checklist já inicializado");
    return;
  }

  // Verifica se o script já está sendo carregado
  if (document.querySelector('script[src*="checklist.js"]')) {
    jirayalog("Script checklist já está carregando");
    return;
  }

  // Cria elemento script para carregar o módulo
  const scriptElemento = document.createElement("script");
  scriptElemento.src = chrome.runtime.getURL("/js/checklist.js");
  scriptElemento.onload = function () {
    jirayalog("Módulo checklist carregado com sucesso");

    // Inicializa o módulo após carregamento
    setTimeout(() => {
      if (window.JirayaTemplateCustomizada) {
        window.JirayaTemplateCustomizada.inicializar();
      }
    }, 100);

    setTimeout(() => {
      this.remove();
    }, 1000);
  };

  scriptElemento.onerror = function () {
    jirayalog("Erro ao carregar módulo checklist");
    this.remove();
  };

  (document.head || document.documentElement).appendChild(scriptElemento);
  jirayalog("Iniciando carregamento do módulo checklist");
}
function jirayalog(log, retorno) {
  if (retorno === undefined) retorno = "";
  if (typeof log === "object") {
    console.log("JIRAYA - ", log, retorno);
  } else {
    console.log("JIRAYA - " + log, retorno);
  }
}


jirayalog("Jiraya carregando...");

// Carrega template-modal.js e template-checklist-formatter.js se ainda não carregados
function carregarScriptJiraya(src, callback) {
  if (document.querySelector('script[src*="' + src + '"]')) {
    if (callback) callback();
    return;
  }
  const script = document.createElement('script');
  script.src = chrome.runtime.getURL('/js/' + src);
  script.onload = function () { if (callback) callback(); };
  (document.head || document.documentElement).appendChild(script);
}




// Checklist: espera-se que checklist.js já esteja incluído como <script> externo e expõe window.JirayaTemplateCustomizada
if (typeof window.JirayaTemplateCustomizada === 'undefined') {
  jirayalog('ATENÇÃO: checklist.js não foi carregado! Certifique-se de incluir checklist.js como <script> externo.');
}

function injetarJQuery(funcaoCallback) {
  if (typeof window.$ === "undefined" && typeof window.jQuery === "undefined") {
    const scriptElemento = document.createElement("script");
    scriptElemento.src = chrome.runtime.getURL("/js/jquery.js");
    scriptElemento.onload = function () {
      jirayalog("jQuery injetado!");
      setTimeout(() => {
        this.remove();
        if (funcaoCallback) funcaoCallback();
      });
    };
    (document.head || document.documentElement).appendChild(scriptElemento);
  } else {
    if (funcaoCallback) funcaoCallback();
  }
}

/**
 * Carrega e inicializa o módulo de timesheet
 */
function carregarModuloTimesheet(elemento) {
  jirayalog("Timesheet app detectado, carregando módulo específico");

  // Verifica se o script já foi carregado
  if (window.jirayaTimesheet && window.jirayaTimesheet.initialized) {
    jirayalog("Módulo timesheet já inicializado");
    return;
  }

  // Verifica se o script já está sendo carregado
  if (document.querySelector('script[src*="timesheet.js"]')) {
    jirayalog("Script timesheet já está carregando");
    return;
  }

  // Cria elemento script para carregar o módulo
  const scriptElemento = document.createElement("script");
  scriptElemento.src = chrome.runtime.getURL("/js/timesheet.js");
  scriptElemento.onload = function () {
    jirayalog("Módulo timesheet carregado com sucesso");

    // Inicializa o módulo após carregamento
    setTimeout(() => {
      if (window.jirayaTimesheet) {
        window.jirayaTimesheet.inicializar();
      }
    }, 100);

    setTimeout(() => {
      this.remove();
    }, 1000);
  };

  scriptElemento.onerror = function () {
    jirayalog("Erro ao carregar módulo timesheet");
    this.remove();
  };

  (document.head || document.documentElement).appendChild(scriptElemento);
  jirayalog("Iniciando carregamento do módulo timesheet");
}

window.ElementosJiraya = {
  detalhesIssue: "#issuedetails",
  modalRegistrarTempo: "#tempo-global-dialog-bundled",
  menuLateral: ".aui-navgroup-inner.sidebar-content-container.jira-navigation",
  menuLateralFooter: ".aui-sidebar-footer",
  tituloIssue: "#summary-val",
  linkIssue: ".aui-nav.aui-nav-breadcrumbs",
  comentario: ".wiki-edit:visible",
  editarComentarioContainer: ".jira-editor-container:visible",
  barraAcoesComentario: ".wiki-button-bar-content",
  botaoComentario: "#footer-comment-button",
  modalEditarIssue: "#edit-issue-dialog",
  geralIssue: "#customfield-panel-1",
  modalEditarComentario: "#edit-comment",
  botaoJirayaEditor: ".botao-template-customizado",
  comentarioAberto: false,
  mensagens: {
    avisoCausaOcorrenciaPendente: "Causa ocorrência pendente",
    testeDeAceitacaoFinalizado: "Concluído com sucesso.",
  },
  emojs: {
    ok: `(/)`,
    erro: `(x)`,
    info: `(i)`,
    alert: `(!)`,
    mais: `(+)`,
    menos: `(-)`,
    pergunta: `(?)`,
    estrela: `(*)`,
    estrela2: `(*y)`,
    bandeiraVermelha: `(flag)`,
    bandeiraBranca: `(flagoff)`,
  },
  textos: {
    botaoCopiar: "copiar", //📋
    botaoCopiarSucesso: "copiado", //✅
    botaoCopiarErro: "erro ao copiar", //❌
  },
};

// Função delegada para o módulo InserirTemplates
function inserirTemplateTextarea(template, textArea) {
  InserirTemplates.inserirTemplateTextarea(template, textArea);
}

// Função delegada para o módulo InserirTemplates
function inserirTemplate(template, idJiraya) {
  InserirTemplates.inserirTemplate(template, idJiraya);
}

injetarJQuery(() => {
  $(function () {
    injetarComponentes();
  })
    .on("click", ElementosJiraya.botaoComentario, function () {
      // jirayalog("Box de comentário aberta");
    })
    // .on("visibilitychange", ElementosJiraya.modalEditarComentario, function () {
    //   console.log("visibilitychange");
    //   if ("hidden" === this.visibilityState) {
    //     jirayalog("Modal de edição de comentário fechado");
    //   } else {
    //     jirayalog("Modal de edição aberto");
    //     setTimeout(() => {
    //       $(ElementosJiraya.modalEditarIssue)
    //         .not("[data-jiraya-injetado='true']")
    //         .each(function () {
    //           $(this).attr("data-jiraya-injetado", "true");
    //           // if (JIRAYA__.tipo == "Manutenção") {
    //           modalEditarIssueAberto(this);
    //           // }
    //         });
    //     });
    //   }
    // })
    .on(
      "click",
      "[id*='edit'], [class*='edit'], [title*='Edit'], [title*='Editar']",
      function () {
        // jirayalog("Botão de editar clicado");
      }
    )
    .on("click", "span:contains('Adicionar comentário')", function () {
      observarElementoVisivel({
        seletor: ElementosJiraya.comentario,
        callback: comentarioAberto,
        nome: "Box de comentário",
        aguardarVisibilidade: true,
      });
    })
    .on(
      "click",
      "span:contains('Adicionar comentário'), .edit-comment",
      function () {
        observarElementoVisivel({
          seletor: ElementosJiraya.comentario,
          callback: comentarioAberto,
          nome: "Box de comentário",
          aguardarVisibilidade: true,
        });
        observarElementoVisivel({
          seletor: ElementosJiraya.editarComentarioContainer,
          callback: tratamentoEditarComentario,
          nome: "Modal de edição de comentário",
          aguardarVisibilidade: true,
        });
      }
    );
});

function observarElementoVisivel(opcoes) {
  const {
    seletor,
    callback,
    nome = seletor,
    aguardarVisibilidade = false,
    maxTentativas = 20,
    intervalo = 100,
    condicao = null,
  } = opcoes;

  $(seletor)
    .not("[data-jiraya-injetado='true']")
    .not("[data-jiraya-processado='true']")
    .each(function () {
      const elemento = $(this);
      elemento.attr("data-jiraya-injetado", "true");
      jirayalog(`${nome} detectado`);

      if (condicao && !condicao(elemento)) {
        jirayalog(`${nome} não atende à condição - ignorando`);
        return;
      }

      if (!aguardarVisibilidade) {
        setTimeout(() => {
          try {
            callback(this);
          } catch (erro) {
            jirayalog(`Erro ${nome} callback:`, erro);
          }
        }, intervalo);
        return;
      }

      function verificarVisibilidade() {
        const visible = elemento.is(":visible");
        const display = elemento.css("display") !== "none";
        const visibility = elemento.css("visibility") !== "hidden";
        const opacity = parseFloat(elemento.css("opacity")) > 0;

        if (visible && display && visibility && opacity) {
          jirayalog(`${nome} está visível - executando callback`);
          elemento.attr("data-jiraya-processado", "true");
          try {
            callback(elemento[0]);
          } catch (erro) {
            jirayalog(`Erro ${nome} callback:`, erro);
          }
          return true;
        }
        return false;
      }

      if (!verificarVisibilidade()) {
        let tentativas = 0;

        const intervalId = setInterval(() => {
          tentativas++;

          if (verificarVisibilidade() || tentativas >= maxTentativas) {
            clearInterval(intervalId);
            if (tentativas >= maxTentativas) {
              jirayalog(
                `${nome} não ficou visível após ${maxTentativas} tentativas`
              );
              elemento.removeAttr("data-jiraya-injetado");
              elemento.removeAttr("data-jiraya-processado");
            }
          }
        }, intervalo);
      }
    });
}

function observadoresJiraya() {
  const observer = new MutationObserver((mutations) => {
    // Verificar se houve mudanças relevantes antes de executar observadores
    let hasRelevantChanges = false;
    
    mutations.forEach(mutation => {
      if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
        // Verificar se algum nó adicionado contém elementos que nos interessam
        mutation.addedNodes.forEach(node => {
          if (node.nodeType === Node.ELEMENT_NODE) {
            const $node = $(node);
            
            // Verificar se o nó ou seus descendentes contêm elementos relevantes
            if (
              $node.is(ElementosJiraya.comentario) ||
              $node.find(ElementosJiraya.comentario).length > 0 ||
              $node.is(ElementosJiraya.modalEditarIssue) ||
              $node.find(ElementosJiraya.modalEditarIssue).length > 0 ||
              $node.is(ElementosJiraya.editarComentarioContainer) ||
              $node.find(ElementosJiraya.editarComentarioContainer).length > 0 ||
              $node.is(ElementosJiraya.geralIssue) ||
              $node.find(ElementosJiraya.geralIssue).length > 0 ||
              $node.is('.preformattedContent.panelContent') ||
              $node.find('.preformattedContent.panelContent').length > 0 ||
              $node.is('#tt-project-timesheet-app') ||
              $node.find('#tt-project-timesheet-app').length > 0 ||
              $node.hasClass('tempo-report-container') ||
              $node.find('.tempo-report-container').length > 0
            ) {
              hasRelevantChanges = true;
            }
          }
        });
      }
    });
    
    // Só executar observadores se houver mudanças relevantes
    if (hasRelevantChanges) {
      jirayalog("Mudanças relevantes detectadas, executando observadores");
      
      observarElementoVisivel({
        seletor: ElementosJiraya.comentario,
        callback: comentarioAberto,
        nome: "Box de comentário",
        aguardarVisibilidade: true,
      });

      observarElementoVisivel({
        seletor: ElementosJiraya.modalEditarIssue,
        callback: modalEditarIssueAberto,
        nome: "Modal de edição",
        aguardarVisibilidade: true,
      });
      observarElementoVisivel({
        seletor: ElementosJiraya.editarComentarioContainer,
        callback: tratamentoEditarComentario,
        nome: "Modal de edição de comentário",
        aguardarVisibilidade: true,
      });

      // observarElementoVisivel({
      //   seletor: ElementosJiraya.modalRegistrarTempo,
      //   callback: modalEditarIssueAberto,
      //   nome: "Registrar tempo",
      //   aguardarVisibilidade: true,
      // });

      observarElementoVisivel({
        seletor: ElementosJiraya.geralIssue,
        callback: abaGeralIssue,
        nome: "Issue geral",
        aguardarVisibilidade: false,
        condicao: (elemento) => JIRAYA__.tipo == "Manutenção",
      });

      // Observer para elementos de código (.preformattedContent.panelContent)
      observarElementoVisivel({
        seletor: ".preformattedContent.panelContent",
        callback: function (elemento) {
          adicionarBotaoCopiar($(elemento));
        },
        nome: "Painel de código",
        aguardarVisibilidade: false,
      });

      // Observer para aplicação de timesheet
      observarElementoVisivel({
        seletor: "#tt-project-timesheet-app",
        callback: function (elemento) {
          carregarModuloTimesheet(elemento);
        },
        nome: "Timesheet App",
        aguardarVisibilidade: true,
      });
      
      // Observador específico para tempo-report-container (apenas se modificado)
      observarElementoVisivel({
        seletor: ".tempo-report-container",
        callback: function (elemento) {
          jirayalog("Elemento tempo-report-container modificado, processando dados dos colaboradores");
          // Aqui você pode adicionar a lógica específica para processar os dados dos colaboradores
          processarDadosColaboradores($(elemento));
        },
        nome: "Container de relatório de tempo",
        aguardarVisibilidade: false,
      });
    }
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
    attributes: true,
  });
}

/**
 * Processa dados dos colaboradores quando o elemento tempo-report-container é modificado
 * Esta função é chamada apenas quando há mudanças no container, evitando verificações desnecessárias
 */
function processarDadosColaboradores($container) {
  // Debounce para evitar múltiplas execuções muito próximas
  if (processarDadosColaboradores.timeout) {
    clearTimeout(processarDadosColaboradores.timeout);
  }
  
  processarDadosColaboradores.timeout = setTimeout(() => {
    jirayalog("Processando dados dos colaboradores no tempo-report-container");
    
    // Verificar se o container ainda existe e tem conteúdo
    if ($container.length === 0 || !$container.is(':visible')) {
      jirayalog("Container não está visível ou não existe, ignorando processamento");
      return;
    }
    
    try {
      // Aqui você pode adicionar a lógica específica para extrair dados dos colaboradores
      // Por exemplo, se precisar processar horas, nomes, etc.
      
      const colaboradores = $container.find('[data-user-id], .user-row, .collaborator-row');
      jirayalog(`Encontrados ${colaboradores.length} elementos de colaboradores`);
      
      colaboradores.each(function(index, elemento) {
        const $colaborador = $(elemento);
        
        // Verificar se já foi processado para evitar reprocessamento
        if (!$colaborador.hasClass('jiraya-processado')) {
          $colaborador.addClass('jiraya-processado');
          
          // Extrair dados do colaborador (adapte conforme necessário)
          const nome = $colaborador.find('.user-name, .collaborator-name').text().trim();
          const horas = $colaborador.find('.hours, .time-logged').text().trim();
          const userId = $colaborador.attr('data-user-id') || $colaborador.data('userId');
          
          if (nome || horas) {
            jirayalog(`Colaborador processado: ${nome} - ${horas}h (ID: ${userId})`);
            
            // Aqui você pode adicionar funcionalidades específicas como:
            // - Adicionar botões de cópia
            // - Calcular estatísticas
            // - Aplicar formatação
            // - etc.
            
            // Exemplo: adicionar botão de copiar se não existir
            if ($colaborador.find('.jiraya-btn-copiar').length === 0) {
              const $btnCopiar = $('<button>')
                .addClass('jiraya-btn-copiar aui-button aui-button-subtle')
                .text('📋')
                .attr('title', 'Copiar informações do colaborador')
                .on('click', function(e) {
                  e.preventDefault();
                  const dadosColaborador = `Nome: ${nome}\nHoras: ${horas}\nID: ${userId}`;
                  
                  if (navigator.clipboard && navigator.clipboard.writeText) {
                    navigator.clipboard.writeText(dadosColaborador);
                    jirayalog(`Dados copiados: ${dadosColaborador}`);
                  }
                });
              
              $colaborador.append($btnCopiar);
            }
          }
        }
      });
      
    } catch (erro) {
      jirayalog("Erro ao processar dados dos colaboradores:", erro);
    }
  }, 300); // Aguarda 300ms para evitar múltiplas execuções
}

window.JIRAYA__ = {};
function injetarComponentes() {
  jirayalog("Jiraya injetado!");

  observadoresJiraya();

  var linksIssue = $(ElementosJiraya.linkIssue);
  detalhesIssue = $(ElementosJiraya.detalhesIssue);

  var tituloCompleto = $(ElementosJiraya.tituloIssue).text().trim();
  var prefixosParaRemover = [
    "Codificação -",
    "Code Review -",
    "Teste Integrado -",
    "Documentação - ",
    "Revisão documentação técnico -",
    "Merge -",
  ];

  var tituloIssue = tituloCompleto;
  prefixosParaRemover.forEach((prefixo) => {
    if (tituloCompleto.startsWith(prefixo)) {
      tituloIssue = tituloCompleto.substring(prefixo.length).trim();
    }
  });

  const projectNameEl = linksIssue.find("#project-name-val");
  const issueLinkFirst = linksIssue.find(".issue-link").first();
  const issueLinkLast = linksIssue.find(".issue-link").last();
  const tipoEl = detalhesIssue
    .find("strong[title=Tipo]")
    .closest(".wrap")
    .find("#type-val");
  const prioridadeEl = detalhesIssue
    .find("strong[title=Prioridade]")
    .closest(".wrap")
    .find("#priority-val");

  window.JIRAYA__ = {
    EQUIPE: obterTextoSeguro(projectNameEl, (texto) =>
      splitSeguro(texto, " - ", 1)
    ),
    ISSUE_PAI: obterTextoSeguro(issueLinkFirst, (texto) =>
      splitSeguro(texto, " ", 0)
    ),
    ISSUE: obterTextoSeguro(issueLinkLast),
    TITULO_PAGINA: tituloCompleto || "",
    TITULO: tituloIssue || "",
    TIPO: obterTextoSeguro(tipoEl),
    PRIORIDADE: obterTextoSeguro(prioridadeEl),
  };

  jirayalog("Issue detectada:", window.JIRAYA__);

  var identificacaoJiraya = $("<div>")
    .append(
      $("<img>")
        .attr("src", chrome.runtime.getURL("/midias/icones/icone48.png"))
        .addClass("jiraya-plugin-icone")
        .addClass("jira-issue-status-lozenge")
        .attr(
          "data-tooltip",
          `<span class="jira-issue-status-tooltip-title">${
            chrome.runtime.getManifest().name
          } - ${chrome.runtime.getManifest().version}</span>`
        )
    )
    .addClass("jiraya-plugin-container");

  $(ElementosJiraya.menuLateralFooter).prepend(identificacaoJiraya);

  // Inicializar botões de copiar para elementos já existentes
  adicionarBotoesCopiarNoformat();
}

function tratamentoEditarComentario($this) {
  jirayalog("tratamentoEditarComentario iniciado para:", $this);

  setTimeout(() => {
    const container = $($this);
    const iframe = container.find("iframe");

    if (iframe.length > 0) {
      jirayalog("Iframe encontrado, configurando auto-resize");

      function ajustarTamanhoContainer(iframeDoc) {
        try {
          const bodyHeight = $(iframeDoc.body).height();
          const scrollHeight = iframeDoc.body.scrollHeight;
          const alturaFinal = Math.max(bodyHeight, scrollHeight);

          jirayalog(
            "Ajustando tamanho - Body:",
            bodyHeight,
            "Scroll:",
            scrollHeight,
            "Final:",
            alturaFinal
          );

          if (alturaFinal > 0) {
            container.css("height", `${alturaFinal + 50}px`);
          }
        } catch (erro) {
          jirayalog("Erro ao ajustar tamanho do container:", erro);
        }
      }

      function configurarObserverIframe(iframeDoc) {
        try {
          ajustarTamanhoContainer(iframeDoc);

          observarElementoVisivel({
            seletor: $(iframeDoc.body),
            callback: function () {
              ajustarTamanhoContainer(iframeDoc);
            },
            nome: "Body do iframe",
            aguardarVisibilidade: false,
            intervalo: 50,
          });

          $(iframeDoc).on("input keyup paste change", function () {
            setTimeout(() => ajustarTamanhoContainer(iframeDoc), 50);
          });

          $(iframeDoc).on(
            "focus blur",
            "textarea, input, [contenteditable]",
            function () {
              setTimeout(() => ajustarTamanhoContainer(iframeDoc), 100);
            }
          );

          return true;
        } catch (erro) {
          jirayalog("Erro ao configurar observer do iframe:", erro);
          return null;
        }
      }

      iframe.on("load", function () {
        try {
          const iframeDoc = this.contentDocument || this.contentWindow.document;
          configurarObserverIframe(iframeDoc);
        } catch (erro) {
          jirayalog("Erro ao acessar conteúdo do iframe no load:", erro);
        }
      });

      if (
        iframe[0].contentDocument &&
        iframe[0].contentDocument.readyState === "complete"
      ) {
        try {
          const iframeDoc =
            iframe[0].contentDocument || iframe[0].contentWindow.document;
          configurarObserverIframe(iframeDoc);
        } catch (erro) {
          jirayalog("Erro ao acessar conteúdo do iframe já carregado:", erro);
        }
      }
    } else {
      jirayalog("Nenhum iframe encontrado no container");
    }
  }, 300);
}

function comentarioAberto($this) {
  var idRandom = Math.floor(Math.random() * 1000000);

  $($this).attr("data-jiraya-id", idRandom);

  ElementosJiraya.comentarioAberto = true;
  jirayalog("comentarioAberto - ID:", idRandom);

  const barraDeFerramentas = $($this).find(
    ".aui-toolbar2 .aui-toolbar2-inner .aui-toolbar2-primary"
  );

  jirayalog("Barra de ferramentas encontrada:", barraDeFerramentas.length > 0);

  barraDeFerramentas.attr("data-jiraya-injetado", "true");
  barraDeFerramentasJiraya({
    elementoPai: barraDeFerramentas,
    id: idRandom,
    modo: "append",
    callback: async function () {
      jirayalog("Callback da barra de ferramentas executado");

      // Garante que o motor de templates está inicializado
      await garantirMotorInicializado();

      const { botoesDiretos, dropdowns } = await criarMenuAreasDinamico(
        idRandom,
        "comentario"
      );
      jirayalog("Botões diretos:", botoesDiretos);
      jirayalog("Dropdowns:", dropdowns);

      const elementoPai = $(
        `.barra-jiraya-editor-body[data-jiraya-id=${idRandom}]`
      );

      // Cria botões diretos (para modelos individuais)
      Object.keys(botoesDiretos).forEach((botaoKey) => {
        const botao = botoesDiretos[botaoKey];

        criarBotaoDireto({
          nome: botao.nome,
          cor: botao.cor,
          acao: botao.acao,
          elementoPai: elementoPai,
          idRandom: idRandom + "_" + botaoKey,
        });
      });

      // Cria dropdowns - categorias ou varios modelos
      Object.keys(dropdowns).forEach((areaKey) => {
        const area = dropdowns[areaKey];

        menuSuspenso({
          tituloBotaoMenu: area.nome,
          idRandom: idRandom + "_" + areaKey,
          elementoPai: elementoPai,
          itens: area.subItens,
          cor: area.cor,
          referencia: "comentario",
          class: "jiraya-botao-area",
        });
      });

      // Se não tiver nenhum item vai criar o botão padrão
      if (
        Object.keys(botoesDiretos).length === 0 &&
        Object.keys(dropdowns).length === 0
      ) {
        menuSuspenso({
          tituloBotaoMenu: "Modelos",
          idRandom: idRandom,
          referencia: "comentario",
          elementoPai: elementoPai,
          itens: {},
        });
      }

      jirayalog(
        "Interface criada - Botões diretos:",
        Object.keys(botoesDiretos).length,
        "| Dropdowns:",
        Object.keys(dropdowns).length
      );
    },
  });
}

function adicionarBotoesCopiarNoformat() {
  jirayalog(
    "Configurando observer para elementos .preformattedContent.panelContent"
  );

  // Processar elementos já existentes na página
  $(".preformattedContent.panelContent").each(function () {
    adicionarBotaoCopiar($(this));
  });
}

function adicionarBotaoCopiar($painel) {
  if ($painel.find(".jiraya-botao-copiar").length > 0) {
    return;
  }

  const $botaoCopiar = $("<button>")
    .addClass("jiraya-botao-copiar")
    .attr("type", "button")
    .attr("title", "Copiar conteúdo")
    .html(ElementosJiraya.textos.botaoCopiar)
    .on("mouseenter", function () {})
    .on("mouseleave", function () {})
    .on("click", async function (e) {
      e.preventDefault();
      e.stopPropagation();

      await copiarConteudo($painel, $botaoCopiar);
    });

  if ($painel.css("position") === "static") {
    $painel.css("position", "relative");
  }

  $painel.append($botaoCopiar);
}

/**
 * Função genérica para copiar conteúdo de elementos
 * @param {jQuery|HTMLElement} elemento - Elemento do qual copiar o conteúdo
 * @param {jQuery} [$botaoFeedback] - Botão opcional para mostrar feedback visual
 * @param {Array} [classesExcluir] - Classes CSS dos elementos a excluir na cópia
 * @returns {Promise<boolean>} - True se copiou com sucesso, false caso contrário
 */
async function copiarConteudo(
  elemento,
  $botaoFeedback = null,
  classesExcluir = [".jiraya-botao-copiar"]
) {
  try {
    const $elemento = $(elemento);
    let texto = "";

    if ($elemento.is("textarea") || $elemento.is('input[type="text"]')) {
      texto = $elemento.val().trim();
    } else if ($elemento.is("[contenteditable]")) {
      const $copia = $elemento.clone();
      classesExcluir.forEach((classe) => $copia.find(classe).remove());
      texto = $copia.text().trim();
    } else {
      const $copia = $elemento.clone();
      classesExcluir.forEach((classe) => $copia.find(classe).remove());
      texto = $copia.text().trim();
    }

    if (!texto) {
      jirayalog("Nenhum texto encontrado para copiar");
      if ($botaoFeedback) mostrarFeedbackCopia($botaoFeedback, false);
      return false;
    }

    if (navigator.clipboard && navigator.clipboard.writeText) {
      try {
        await navigator.clipboard.writeText(texto);
        jirayalog(
          "Texto copiado com sucesso via Clipboard API:",
          texto.substring(0, 50) + "..."
        );
        if ($botaoFeedback) mostrarFeedbackCopia($botaoFeedback, true);
        return true;
      } catch (error) {
        jirayalog("Falha na Clipboard API, usando fallback:", error);
        return copiarTextoFallback(texto, $botaoFeedback);
      }
    } else {
      return copiarTextoFallback(texto, $botaoFeedback);
    }
  } catch (error) {
    jirayalog("Erro ao copiar conteúdo:", error);
    if ($botaoFeedback) mostrarFeedbackCopia($botaoFeedback, false);
    return false;
  }
}

function copiarTextoFallback(texto, $botao) {
  try {
    const $temp = $("<textarea>")
      .val(texto)
      .css({
        position: "fixed",
        top: "-9999px",
        left: "-9999px",
        opacity: 0,
      })
      .appendTo("body");

    $temp[0].select();
    $temp[0].setSelectionRange(0, 99999);
    const sucesso = document.execCommand("copy");

    $temp.remove();

    if ($botao) mostrarFeedbackCopia($botao, sucesso);
    jirayalog("Fallback copy result:", sucesso ? "sucesso" : "falha");
    return sucesso;
  } catch (error) {
    jirayalog("Erro no fallback de cópia:", error);
    if ($botao) mostrarFeedbackCopia($botao, false);
    return false;
  }
}

/**
 * Função de conveniência para copiar texto de textareas
 * @param {jQuery|HTMLElement} textarea - Elemento textarea
 * @param {jQuery} [$botaoFeedback] - Botão opcional para feedback visual
 * @returns {Promise<boolean>}
 */
async function copiarTexto(textarea, $botaoFeedback = null) {
  return await copiarConteudo(textarea, $botaoFeedback, []);
}

/**
 * Função de conveniência para copiar conteúdo HTML de elementos (excluindo botões)
 * @param {jQuery|HTMLElement} elemento - Elemento HTML
 * @param {jQuery} [$botaoFeedback] - Botão opcional para feedback visual
 * @param {Array} [classesExtrasExcluir] - Classes extras a excluir além dos botões padrão
 * @returns {Promise<boolean>}
 */
async function copiarElemento(
  elemento,
  $botaoFeedback = null,
  classesExtrasExcluir = []
) {
  const classesExcluir = [".jiraya-botao-copiar", ...classesExtrasExcluir];
  return await copiarConteudo(elemento, $botaoFeedback, classesExcluir);
}

function mostrarFeedbackCopia($botao, sucesso) {
  const textoOriginal = $botao.html();
  const corOriginal = $botao.css("backgroundColor");

  if (sucesso) {
    $botao.html(ElementosJiraya.textos.botaoCopiarSucesso);
  } else {
    $botao.html(ElementosJiraya.textos.botaoCopiarErro);
  }

  setTimeout(function () {
    $botao.html(textoOriginal);
  }, 2000);
}

function barraDeFerramentasJiraya(opt = {}) {
  var elemento = opt.elementoPai;
  if (
    elemento.length > 0 &&
    elemento.find(".barra-jiraya-editor").length == 0
  ) {
    var barra = $("<div>")
      .attr("data-jiraya-id", opt.id)
      .addClass("barra-jiraya-editor")
      .append(
        $("<div>")
          .addClass("barra-jiraya-editor-cointainer")
          .attr("data-jiraya-id", opt.id)
          .append(
            $("<div>")
              .addClass("barra-jiraya-editor-icone")
              .append(
                $("<img>")
                  .attr(
                    "src",
                    chrome.runtime.getURL("/midias/icones/icone48.png")
                  )
                  .addClass("jiraya-plugin-icone")
                  .addClass("jira-issue-status-lozenge")
                  .attr(
                    "data-tooltip",
                    `<span class="jira-issue-status-tooltip-title">${
                      chrome.runtime.getManifest().name
                    } - ${chrome.runtime.getManifest().version}</span>`
                  )
              )
          )
          .append(
            $("<div>")
              .addClass("barra-jiraya-editor-body")
              .attr("data-jiraya-id", opt.id)
          )
      );
    var containerJiraya = elemento;
    if (opt.modo === "prepend") {
      containerJiraya.prepend(barra);
    } else if (opt.modo === "before") {
      containerJiraya.before(barra);
    } else if (opt.modo === "after") {
      containerJiraya.after(barra);
    } else {
      containerJiraya.append(barra);
    }
  }

  observarElementoVisivel({
    seletor: $(".barra-jiraya-editor-body[data-jiraya-id='" + opt.id + "']"),
    callback: opt.callback
      ? async function (element) {
          await opt.callback(element);
        }
      : function () {},
    nome: "Barra de ferramentas Jiraya",
    aguardarVisibilidade: true,
  });

  // (Sticky removido)
}

function menuSuspenso(opt = {}) {
  jirayalog(opt.elementoPai);
  if (!opt.elementoPai) {
    jirayalog("menuSuspenso - Elemento pai não informado");
    return;
  }

  var botao = $("<div>")
    .addClass("aui-buttons botao-template-customizado")
    .append(
      $("<a>")
        .attr("href", "#")
        .html("Jiraya")
        .addClass("aui-button aui-button-subtle wiki-edit-operation")
    );

  var ul = $("<ul>").addClass("aui-list-truncate");
  if (opt.itens) {
    Object.keys(opt.itens).forEach(function (key) {
      var item = opt.itens[key];

      // Se é um separador de categoria
      if (item.separador) {
        ul.append(
          $("<li>")
            .addClass("jiraya-categoria-separador")
            .append(
              $("<span>").html(item.nome).css({
                "font-weight": "bold",
                color: "#7a869a",
                "font-size": "11px",
                padding: "8px 12px 4px",
                display: "block",
                "text-transform": "uppercase",
                "letter-spacing": "0.5px",
                "border-bottom": "1px solid #dfe1e6",
                "margin-bottom": "4px",
              })
            )
        );
      } else if (item.tipo === "menuSuspenso" && item.subItens) {
        // Submenu de categoria
        var liCategoria = $("<li>").addClass("jiraya-submenu").css({
          position: "relative",
        });

        var setaParaDireita = $("<span>")
          .addClass("jiraya-seta")
          .css("transform", "rotate(-90deg)")
          .append(
            `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14"><g fill="none" fill-rule="evenodd"><path d="M3.29175 4.793c-.389.392-.389 1.027 0 1.419l2.939 2.965c.218.215.5.322.779.322s.556-.107.769-.322l2.93-2.955c.388-.392.388-1.027 0-1.419-.389-.392-1.018-.392-1.406 0l-2.298 2.317-2.307-2.327c-.194-.195-.449-.293-.703-.293-.255 0-.51.098-.703.293z" fill="#344563"></path></g></svg>`
          );

        var linkCategoria = $("<a>")
          .attr("href", "#")
          .addClass("wiki-edit-operation jiraya-categoria-menu")
          .html(`${item.nome}`)
          .append(setaParaDireita)
          .css({
            display: "flex",
            "justify-content": "space-between",
            "align-items": "center",
            padding: "8px 12px",
            color: "#42526e",
            "text-decoration": "none",
          });

        var subUl = $("<ul>").addClass("jiraya-submenu-itens").css({
          display: "none",
          position: "absolute",
          left: "100%",
          top: "0",
          background: "white",
          border: "1px solid #dfe1e6",
          "box-shadow": "0 2px 8px rgba(0,0,0,0.1)",
          "z-index": "10000",
          "min-width": "200px",
          "border-radius": "3px",
          "list-style": "none",
          padding: "4px 0",
          margin: "0",
        });

        // Adiciona itens do submenu
        Object.keys(item.subItens).forEach(function (subKey) {
          var subItem = item.subItens[subKey];
          subUl.append(
            $("<li>").append(
              $("<a>")
                .attr("href", "#")
                .addClass("wiki-edit-operation")
                .html(subItem.nome)
                .css({
                  padding: "8px 12px",
                  display: "block",
                  color: "#42526e",
                  "text-decoration": "none",
                })
                .on("click", function (e) {
                  e.preventDefault();
                  e.stopPropagation();
                  if (subItem.acao && typeof subItem.acao === "function") {
                    subItem.acao();
                  }
                  // Fecha o menu
                  $(this).closest(".aui-dropdown2").hide();
                })
                .on("mouseenter", function () {
                  $(this).css("background-color", "#f4f5f7");
                })
                .on("mouseleave", function () {
                  $(this).css("background-color", "transparent");
                })
            )
          );
        });

        // Eventos de hover para o submenu
        var hideTimeout;

        liCategoria
          .on("mouseenter", function () {
            jirayalog("Mouse entrou na categoria:", item.nome);

            // Limpa qualquer timeout de esconder
            if (hideTimeout) {
              clearTimeout(hideTimeout);
            }

            // Esconde todos os outros submenus
            $(this).siblings().find(".jiraya-submenu-itens").hide();

            // Calcula a posição do submenu para garantir que fique visível
            var $this = $(this);
            var submenuOffset = $this.position();
            var submenuHeight = subUl.outerHeight();
            var viewportHeight = $(window).height();

            // Ajusta a posição vertical se necessário
            var topPosition = 0;
            if (submenuOffset.top + submenuHeight > viewportHeight) {
              topPosition = Math.max(0, -submenuHeight + $this.outerHeight());
            }

            subUl
              .css({
                top: topPosition + "px",
                display: "block",
              })
              .addClass("show");
            jirayalog(
              "Submenu mostrado para:",
              item.nome,
              "- Elemento:",
              subUl
            );
          })
          .on("mouseleave", function () {
            // Aguarda um pouco antes de esconder para permitir navegação para o submenu
            hideTimeout = setTimeout(function () {
              subUl.css("display", "none").removeClass("show");
              jirayalog("Submenu escondido por timeout");
            }, 0);
          });

        // Eventos para o próprio submenu
        subUl
          .on("mouseenter", function () {
            // Limpa o timeout de esconder quando mouse entra no submenu
            if (hideTimeout) {
              clearTimeout(hideTimeout);
            }
            jirayalog("Mouse entrou no submenu");
          })
          .on("mouseleave", function () {
            // Esconde imediatamente quando sai do submenu
            $(this).css("display", "none").removeClass("show");
            jirayalog("Mouse saiu do submenu");
          });

        linkCategoria.on("click", function (e) {
          e.preventDefault();
          e.stopPropagation();
        });

        liCategoria.append(linkCategoria).append(subUl);
        ul.append(liCategoria);

        // Debug log para verificar se o submenu foi criado
        jirayalog(
          "Submenu criado para categoria:",
          item.nome,
          "com",
          Object.keys(item.subItens).length,
          "itens"
        );
      } else {
        // Item normal do menu
        ul.append(
          $("<li>").append(
            $("<a>")
              .attr("href", "#")
              .addClass("wiki-edit-operation")
              .attr("data-operation", "noformat")
              .html(`${item.nome}`)
              .css(
                item.nome.startsWith("   ") ? { "padding-left": "20px" } : {}
              )
              .on("click", function (e) {
                e.preventDefault();
                e.stopPropagation();
                // Executa ação após um pequeno delay para evitar conflitos
                setTimeout(() => {
                  if (item.acao && typeof item.acao === "function") {
                    item.acao();
                  }
                }, 10);
                // Fecha o menu imediatamente
                $(this).closest(".aui-dropdown2").hide();
              })
          )
        );
      }
    });
  }

  var menu = $("<div>")
    .attr("id", "menu-templates-jiraya-" + opt.idRandom)
    .addClass("aui-dropdown2 aui-style-default jiraya-menu-isolado aui-layer")
    .attr("resolved", "")
    .attr("tabindex", "-1")
    .append($("<div>").addClass("aui-dropdown2-section").append(ul));
  // .append(
  //   $("<div>")
  //     .addClass("aui-dropdown2-section")
  //     .append(
  //       $("<ul>")
  //         .addClass("aui-list-truncate")
  //         .append(
  //           $("<li>").append(
  //             $("<a>")
  //               .attr("href", "")
  //               .attr("target", "_blank")
  //               .attr("title", "Texto")
  //               .text("Ajuda sobre o texto")
  //           )
  //         )
  //     )
  // );

  var botaoMenu = $("<a>")
    .attr("href", "#")
    .addClass(
      "aui-button aui-button-subtle aui-dropdown2-trigger jiraya-menu-template"
    )
    .attr("aria-owns", "menu-templates-jiraya-" + opt.idRandom)
    .attr("aria-haspopup", "true")
    .attr("aria-controls", "menu-templates-jiraya-" + opt.idRandom)
    .attr("original-title", opt.tituloBotaoMenu)
    .attr("resolved", "")
    .attr("aria-expanded", "false")
    // .attr("aria-disabled", "true")
    .append(
      $("<span>")
        .addClass("jiraya-menu-titulo")
        // .addClass("aui-icon aui-icon-small aui-iconfont-add") // icone no lugar do nome
        .html(`${opt.tituloBotaoMenu}`)
    );

  if (opt.class) {
    botaoMenu.addClass(opt.class);
  }
  if (opt.style) {
    botaoMenu.attr("style", opt.style);
  }
  // if (opt.cor) {
  //   botaoMenu.css({
  //     "background-color": opt.cor,
  //     "color": "white",
  //     "border-color": opt.cor
  //   });
  //   botaoMenu.find(".jiraya-menu-titulo").css("color", "white");
  // }

  if (!opt.modo) opt.modo = "append";

  // Previne eventos que causam salvamento automático
  botaoMenu.on("click", function (e) {
    e.preventDefault();
    e.stopPropagation();
    // Não fazer nada aqui - deixa o AUI gerenciar o dropdown
  });

  // Previne propagação de eventos do menu
  menu.on("click", function (e) {
    e.stopPropagation();
  });

  // Adiciona eventos para gerenciar submenus
  menu.on("mouseleave", function () {
    $(this).find(".jiraya-submenu-itens").hide();
  });

  // Garante que o menu principal tenha position relative
  menu.css("position", "relative");

  var containerJiraya = opt.elementoPai;
  if (opt.modo === "prepend") {
    containerJiraya.prepend(botaoMenu).prepend(menu);
  } else if (opt.modo === "before") {
    containerJiraya.before(botaoMenu).before(menu);
  } else if (opt.modo === "after") {
    containerJiraya.after(botaoMenu).after(menu);
  } else {
    containerJiraya.append(botaoMenu).append(menu);
  }
}

function criarInformativoSimples(opcoes = {}) {
  var { titulo, conteudo, icone, cor, corBorda, corBackground, tema } = opcoes;
  //
  if (tema == "warning") {
    cor = "#333";
    corBorda = "#ffeaae";
    corBackground = "#fffdf6";
    icone = '<i class="aui-icon aui-icon-small aui-iconfont-info"></i>';
  } else if (tema == "success") {
    cor = "#333";
    corBorda = "#91c89c";
    corBackground = "#f3f9f4";
    icone = '<i class="aui-icon aui-icon-small aui-iconfont-success"></i>';
  } else if (tema == "error") {
    cor = "#cf4336";
    corBorda = "#d04437";
    corBackground = "#fff8f7";
    icone = '<i class="aui-icon aui-icon-small aui-iconfont-error"></i>';
  } else if (tema == "info") {
    cor = "#344563";
    corBorda = "#dfe1e6";
    corBackground = "#f4f5f7";
    icone = '<i class="aui-icon aui-icon-small aui-iconfont-info"></i>';
  }

  var informativoSimples = $("<div>")
    .addClass("jiraya-informativo-simples")
    .css({
      "background-color": corBackground,
      border: "1px solid",
      "border-color": corBorda,
      color: cor,
      "border-radius": "4px",
      padding: "12px",
      margin: "8px 0",
      "font-size": "13px",
      "line-height": "1.4",
    })
    .append(
      $("<div>")
        .addClass("jiraya-informativo-titulo")
        .css({
          "font-weight": "bold",
          "margin-bottom": "4px",
          display: "flex",
          "align-items": "center",
          gap: "6px",
        })
        .html(`${icone} ${titulo}`)
    );

  if (conteudo) {
    informativoSimples.append(
      $("<div>")
        .addClass("jiraya-informativo-conteudo")
        .css({
          color: "#424242",
        })
        .html(conteudo)
    );
  }

  return informativoSimples;
}

function criarAvisoCausaOcorrencia() {
  var setaParaBaixo = $("<span>")
    .addClass("jiraya-seta")
    .css("transform", "rotate(-90deg)")
    .append(
      `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14"><g fill="none" fill-rule="evenodd"><path d="M3.29175 4.793c-.389.392-.389 1.027 0 1.419l2.939 2.965c.218.215.5.322.779.322s.556-.107.769-.322l2.93-2.955c.388-.392.388-1.027 0-1.419-.389-.392-1.018-.392-1.406 0l-2.298 2.317-2.307-2.327c-.194-.195-.449-.293-.703-.293-.255 0-.51.098-.703.293z" fill="#344563"></path></g></svg>`
    );

  var setaParaCima = $("<span>")
    .addClass("jiraya-seta")
    .append(
      `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14"><g fill="none" fill-rule="evenodd"><path d="M3.29175 4.793c-.389.392-.389 1.027 0 1.419l2.939 2.965c.218.215.5.322.779.322s.556-.107.769-.322l2.93-2.955c.388-.392.388-1.027 0-1.419-.389-.392-1.018-.392-1.406 0l-2.298 2.317-2.307-2.327c-.194-.195-.449-.293-.703-.293-.255 0-.51.098-.703.293z" fill="#344563"></path></g></svg>`
    );

  var avisoCausaOcorrencia = $("<div>")
    .addClass("jiraya-aviso-causa-ocorrencia")
    .append(
      $("<div>")
        .addClass("jiraya-aviso-header")
        .html("📋 <span>Instruções para Causa Ocorrência</span> ")
        .append(setaParaBaixo)
        .on("click", function () {
          var conteudo = $(this).next(".jiraya-instrucoes-content");
          var isVisible = conteudo.is(":visible");

          if (isVisible) {
            conteudo.slideUp(300);
            $(this)
              .empty()
              .html("📋 <span>Instruções para Causa Ocorrência</span> ")
              .append(setaParaBaixo);
          } else {
            conteudo.slideDown(300);
            $(this)
              .empty()
              .html("📋 <span>Instruções para Causa Ocorrência</span> ")
              .append(setaParaCima);
          }
        })
    )
    .append(
      $("<div>").addClass("jiraya-instrucoes-content").html(`
        <div class="jiraya-secao-classificacao">
          <h4 class="jiraya-titulo-secao">
            🔍 CLASSIFICAÇÃO DO PROBLEMA
          </h4>
          <p class="jiraya-intro-texto">O problema poderá ser classificado em 3 opções:</p>
          
          <div class="jiraya-card-recente">
            <span class="jiraya-label-recente">RECENTE:</span> Manutenções geradas por outras issues, a menos de 1 ano da data de abertura da issue de manutenção, rejeição-manutenção, história ou legislação.
          </div>
          
          <div class="jiraya-card-legado">
            <span class="jiraya-label-legado">LEGADO:</span> Manutenções geradas por outras issues, a mais de 1 ano da data de abertura da issue de manutenção, rejeição-manutenção, história ou legislação.
          </div>
          
          <div class="jiraya-card-novo">
            <span class="jiraya-label-novo">NOVO:</span> Manutenções geradas por problemas novos, não previstos ou mapeados anteriormente, seja na codificação da inovação, ou em manutenções que aconteceram.
          </div>
        </div>
        
        <div class="jiraya-secao-campos">
          <h4 class="jiraya-titulo-secao">
            📝 CAMPOS OBRIGATÓRIOS
          </h4>
          
          <div class="jiraya-campo-item">
            <span class="jiraya-campo-label">• CLASSIFICAÇÃO:</span> Mencionar uma das opções acima (Recente/Legado/Novo).
          </div>
          
          <div class="jiraya-campo-item">
            <span class="jiraya-campo-label">• FATO:</span> Informar a issue que originou essa manutenção. No caso de classificação "Novo", informar "Não Se Aplica".
          </div>
          
          <div class="jiraya-campo-item">
            <span class="jiraya-campo-label">• CAUSA:</span> Qual o problema que precisa ser resolvido.
          </div>
          
          <div class="jiraya-campo-item">
            <span class="jiraya-campo-label">• AÇÃO:</span> Ação realizada para solucionar o problema e evitar que se repita.
          </div>
          
          <div class="jiraya-campo-item">
            <span class="jiraya-campo-label">• AUTOMAÇÃO:</span> "Sim" (quando houver possibilidade de criar testes automatizados) ou "Não" (quando não houver possibilidade).
          </div>
          
          <div class="jiraya-campo-item">
            <span class="jiraya-campo-label">• TESTE:</span> Na reunião de análise de causa ocorrência, quando houver possibilidade de automação, deverá ser criada uma issue para este fim, vinculada à issue de manutenção como predecessora.
          </div>
        </div>
        
        <div class="jiraya-secao-exemplo">
          <h4 class="jiraya-titulo-secao">
            📄 EXEMPLO DE CAUSA OCORRÊNCIA
          </h4>
          
          <div class="jiraya-exemplo-box">
            <div class="jiraya-exemplo-item">
              <span class="jiraya-exemplo-label">[Classificação]</span> Recente
            </div>
            
            <div class="jiraya-exemplo-item">
              <span class="jiraya-exemplo-label">[Fato]</span> DSUPPDVTURING-XXXX
            </div>
            
            <div class="jiraya-exemplo-item">
              <span class="jiraya-exemplo-label">[Causa]</span> A implementação da issue DSUPPDVTURING-XXXX no método XXXXX causou o erro reportado.
            </div>
            
            <div class="jiraya-exemplo-item">
              <span class="jiraya-exemplo-label">[Ação]</span> Foi corrigido o método XXXX para não executar de maneira erronia a ação de calculo.
            </div>
            
            <div class="jiraya-exemplo-item">
              <span class="jiraya-exemplo-label">[Automação]</span> Sim
            </div>
            
            <div class="jiraya-exemplo-item">
              <span class="jiraya-exemplo-label">[Teste]</span> Deverá ser preenchido quando a issue for criada.
            </div>
          </div>
        </div>
      `)
    );

  return avisoCausaOcorrencia;
}

function editarIssue(opt = {}) {
  $this = opt.elemento;

  Object.keys(opt.campos).forEach(function (campoKey) {
    var idRandom = Math.floor(Math.random() * 1000000);
    var campo = opt.campos[campoKey];
    var filedGroupCausaOcorrencia = $($this)
      .find(`.field-group label:contains('${campo.titulo}')`)
      .closest(".field-group");

    var labelCausaOcorrencia = filedGroupCausaOcorrencia.find("label");
    var textareaCausaOcorrencia = filedGroupCausaOcorrencia.find("textarea");

    if (campo.informativo && campo.informativo.html) {
      if (campo.informativo.modo == "after") {
        filedGroupCausaOcorrencia.after(campo.informativo.html);
      } else if (campo.informativo.modo == "before") {
        filedGroupCausaOcorrencia.before(campo.informativo.html);
      } else if (campo.informativo.modo == "prepend") {
        filedGroupCausaOcorrencia.prepend(campo.informativo.html);
      } else {
        filedGroupCausaOcorrencia.append(campo.informativo.html);
      }
    }

    // Configura auto-resize da textarea usando o módulo InserirTemplates
    InserirTemplates.configurarRedimensionamentoAutomatico(
      textareaCausaOcorrencia
    );

    // Usa o novo sistema de referências se definido
    if (campo.referencia) {
      jirayalog(
        "Criando menu por referência:",
        campo.referencia,
        "para campo:",
        campo.titulo
      );

      barraDeFerramentasJiraya({
        elementoPai: textareaCausaOcorrencia,
        id: idRandom,
        modo: "before",
        callback: async function () {
          // Usa o novo sistema de referências
          await criarMenuPorReferencia(
            campo.referencia,
            textareaCausaOcorrencia,
            idRandom
          );
        },
      });
    } else if (campo.barraDeFerramentas) {
      // Sistema legado (mantido para compatibilidade)
      barraDeFerramentasJiraya({
        elementoPai: textareaCausaOcorrencia,
        id: idRandom,
        modo: campo.barraDeFerramentas.modo || "before",
        callback: function () {
          var itensMenuSuspenso = campo.barraDeFerramentas.menuSuspenso.itens;
          var itens = {};
          Object.keys(itensMenuSuspenso).forEach(function (chave) {
            var item = itensMenuSuspenso[chave];
            itens[chave] = {
              nome: item.nome,
              acao: async function () {
                const conteudoModelo = await MODELOS[item.modelo]();
                inserirTemplateTextarea(
                  conteudoModelo,
                  textareaCausaOcorrencia
                );
              },
            };
          });
          jirayalog("itens", itens);
          menuSuspenso({
            tituloBotaoMenu:
              campo.barraDeFerramentas.menuSuspenso.tituloBotaoMenu,
            idRandom: idRandom,
            elementoPai: $(
              `.barra-jiraya-editor-body[data-jiraya-id=${idRandom}]`
            ),
            itens: itens,
          });
        },
      });
    }

    if (
      textareaCausaOcorrencia.length == 0 ||
      $(ElementosJiraya.botaoJirayaEditor).length > 0
    ) {
      return;
    }
  });
}

async function modalEditarIssueAberto($this) {
  // Garante que o motor está inicializado
  await garantirMotorInicializado();

  const todasAreas = motorTemplatesJiraya.obterModelosPorArea();
  const camposModal = {};

  Object.keys(todasAreas).forEach((areaId) => {
    const area = todasAreas[areaId];
    const infoArea = area.info;
    const referencia = infoArea.referencia;
    const tipoReferencia = infoArea.tipoReferencia;

    // Só processa referências que são explicitamente marcadas como "modal"
    if (referencia && tipoReferencia === "modal") {
      jirayalog("Campo encontrado para modal:", referencia, "da área:", areaId);

      // Cria configuração do campo baseada na referência
      const configCampo = {
        titulo: referencia, // Usa a própria referência como título do campo
        referencia: referencia,
      };

      // Adiciona informativo se configurado no JSON
      if (infoArea.informativo) {
        const infoConfig = infoArea.informativo;
        jirayalog("Configuração de informativo encontrada:", infoConfig);

        let htmlInformativo = null;

        // Gera HTML baseado no tipo
        switch (infoConfig.tipo) {
          case "causaOcorrencia":
            htmlInformativo = criarAvisoCausaOcorrencia();
            break;

          case "customHtml":
            htmlInformativo = infoConfig.conteudo || "";
            break;

          case "simples":
            htmlInformativo = criarInformativoSimples({
              titulo: infoConfig.titulo || "Informação",
              conteudo: infoConfig.conteudo || "",
              tema: infoConfig.tema || "warning", // warning, success, error, info
              icone: infoConfig.icone,
              cor: infoConfig.cor,
              corBackground: infoConfig.corBackground,
              corBorda: infoConfig.corBorda,
            });
            break;

          default:
            jirayalog("Tipo de informativo não reconhecido:", infoConfig.tipo);
        }

        if (htmlInformativo) {
          configCampo.informativo = {
            html: htmlInformativo,
            modo: infoConfig.modo || "before",
          };
        }
      }

      // Usa a referência como chave (mas sanitizada para identificador)
      const chaveCampo = referencia
        .toLowerCase()
        .replace(/\s+/g, "")
        .replace(/[^a-z0-9]/g, "");
      camposModal[chaveCampo] = configCampo;
    }
  });

  jirayalog(
    "Campos configurados automaticamente para modal:",
    Object.keys(camposModal)
  );

  editarIssue({
    elemento: $this,
    campos: camposModal,
  });
}

function abaGeralIssue($this) {
  var idRandom = Math.floor(Math.random() * 1000000);
  $($this).attr("data-jiraya-id", idRandom);

  var filedGroupCausaOcorrencia = $($this)
    .find(".item .wrap strong:contains('Causa Ocorrência')")
    .closest(".item");

  var labelCausaOcorrencia = filedGroupCausaOcorrencia.find("strong");
  var boxDatextareaCausaOcorrencia = filedGroupCausaOcorrencia.find(
    "[data-fieldtype='textarea']"
  );

  var conteudo = boxDatextareaCausaOcorrencia.find(".flooded");

  if (conteudo.length == 0) {
    var notificacao = $("<span>")
      .addClass("aui-label ghx-label ghx-label-single ghx-label-14")
      .attr(
        "data-tooltip",
        `<span class="jira-issue-status-tooltip-title">${ElementosJiraya.mensagens.avisoCausaOcorrenciaPendente}</span>`
      )
      .attr("original-title", "")
      .text(ElementosJiraya.mensagens.avisoCausaOcorrenciaPendente);

    var avisoPreenchimento = $("<span>")
      .css({
        color: "red",
        "font-weight": "bold",
        "margin-left": "10px",
      })
      .text("⚠️ Preencha a causa ocorrência assim que possível.");

    $(ElementosJiraya.tituloIssue).append("<br>").append(notificacao);
    return;
  }
  // filedGroupCausaOcorrencia.prepend(criarAvisoCausaOcorrencia());

  // menuSuspenso({
  //   modo: "append",
  //   style: "background-color: #344563; color: white;",
  //   tituloBotaoMenu: "Templates Jiraya",
  //   idRandom: idRandom,
  //   elementoPai: labelCausaOcorrencia,
  //   itens: {
  //     templateCodificacao: {
  //       nome: "Causa Ocorrência",
  //       acao: function () {
  //         templateCausaOcorrenciaGeralIssue(
  //           idRandom,
  //           boxDatextareaCausaOcorrencia
  //         );
  //       },
  //     },
  //   },
  // });
}

// function templateCausaOcorrenciaGeralIssue(
//   idRandom,
//   boxDatextareaCausaOcorrencia
// ) {
//   boxDatextareaCausaOcorrencia.trigger("click");

//   setTimeout(() => {
//     simularClickFora(boxDatextareaCausaOcorrencia[0]);

//     var textareaCausaOcorrencia = boxDatextareaCausaOcorrencia.find("textarea");
//     textareaCausaOcorrencia.focus();

//     jirayalog(textareaCausaOcorrencia);

//     textareaCausaOcorrencia.on("input", function () {
//       let linhas = $(this).val().split("\n").length;
//       const minRows = 10;
//       const maxRows = 30;
//       if (linhas < minRows) linhas = minRows;

//       $(this).attr("rows", Math.max(minRows, Math.min(linhas, maxRows)));
//     });

//     textareaCausaOcorrencia.trigger("input");

//     templateCausaOcorrencia(idRandom, textareaCausaOcorrencia);
//   }, 200);
// }

function clickSimulado(element) {
  const clickEvent = new MouseEvent("click", {
    bubbles: true,
    cancelable: true,
    view: window,
  });
  element.dispatchEvent(clickEvent);
}

function simularClickFora(elemento) {
  elemento.blur();

  const clickForaEvento = new MouseEvent("mousedown", {
    bubbles: true,
    cancelable: true,
    view: window,
    clientX: 0,
    clientY: 0,
  });
  document.body.dispatchEvent(clickForaEvento);

  const mouseUpEvento = new MouseEvent("mouseup", {
    bubbles: true,
    cancelable: true,
    view: window,
    clientX: 0,
    clientY: 0,
  });
  document.body.dispatchEvent(mouseUpEvento);
}

/**
 * Garante que o motor de templates está inicializado
 * @returns {Promise<boolean>} True se inicializado com sucesso, false caso contrário
 */
async function garantirMotorInicializado() {
  if (!motorTemplatesJiraya.inicializado) {
    try {
      jirayalog("Inicializando sistema de modelos...");
      await motorTemplatesJiraya.inicializar();
      return true;
    } catch (erro) {
      jirayalog("Erro ao inicializar motor de templates:", erro);
      return false;
    }
  }
  return true;
}

/**
 * Inicializa o sistema de modelos (função legada mantida para compatibilidade)
 */
async function inicializarSistemaModelos() {
  try {
    await motorTemplatesJiraya.inicializar();
    jirayalog("Sistema de modelos inicializado com sucesso!");
  } catch (erro) {
    console.error("Falha ao inicializar sistema de modelos:", erro);
    jirayalog(
      "Falha ao inicializar sistema de modelos - usando modelos legados"
    );
  }
}

/**
 * Função auxiliar para obter modelo com contexto personalizado
 */
async function obterModelo(chaveModelo, contextoPersonalizado = {}) {
  if (motorTemplatesJiraya.inicializado) {
    return await motorTemplatesJiraya.processarModelo(chaveModelo);
  } else {
    // Fallback para sistema legado
    return MODELOS[chaveModelo] ? await MODELOS[chaveModelo]() : "";
  }
}

/**
 * Função para criar menu de modelos por categorias
 * @param {string} idAleatorio - ID único para identificar o menu
 * @param {string} [referencia] - Referência para filtrar áreas (opcional)
 */
async function criarMenuAreasDinamico(idAleatorio, referencia = null) {
  // Garante que o motor está inicializado
  const motorInicializado = await garantirMotorInicializado();
  if (!motorInicializado) {
    return { botoesDiretos: {}, dropdowns: {} };
  }

  // Se há referência específica, filtra áreas por ela, senão pega todas
  const modelosPorArea = referencia
    ? motorTemplatesJiraya.obterAreasPorReferencia(referencia)
    : motorTemplatesJiraya.obterModelosPorArea();
  jirayalog(
    "Áreas encontradas" +
      (referencia ? ` para referência '${referencia}'` : "") +
      ":",
    Object.keys(modelosPorArea)
  );

  const botoesDiretos = {}; // Modelos que viram botões diretos
  const dropdowns = {}; // Áreas que viram dropdowns

  // Processa cada área
  Object.keys(modelosPorArea).forEach((areaId) => {
    const area = modelosPorArea[areaId];
    const infoArea = area.info;
    const temModelosDiretos =
      area.modelosDiretos && area.modelosDiretos.length > 0;
    const temCategorias = Object.keys(area.categorias).length > 0;

    // MODELOS DIRETOS - viram botões individuais
    if (temModelosDiretos) {
      area.modelosDiretos.forEach((modelo) => {
        // Integração especial para checklistValidacao
        if (modelo.tipoDinamico && modelo.arquivo) {
          botoesDiretos[`modelo_direto_${modelo.chave}`] = {
            nome: modelo.nome,
            cor: infoArea.cor || "#666",
            tipo: "botaoDireto",
            acao: async function () {
              window.JirayaTemplateCustomizada.abrirModalTemplateCustomizada(
                chrome.runtime.getURL("modelos/" + modelo.arquivo),
                function(respostas, campos) {
                  const template = window.JirayaTemplateCustomizada.gerarTemplateCustomizada(respostas, campos);
                  inserirTemplate(template, idAleatorio);
                }
              );
            },
          };
        } else {
          botoesDiretos[`modelo_direto_${modelo.chave}`] = {
            nome: modelo.nome,
            cor: infoArea.cor || "#666",
            tipo: "botaoDireto",
            acao: async function () {
              const conteudo = await motorTemplatesJiraya.processarModelo(
                modelo.chave
              );
              inserirTemplate(conteudo, idAleatorio);
            },
          };
        }
      });
    }

    // const nomePadrao = "Modelos";
    const nomePadrao = "";
    // CATEGORIAS - viram dropdown da área
    if (temCategorias) {
      dropdowns[`area_${areaId}`] = {
        nome: `${infoArea.icone || "📁"} ${infoArea.nome || nomePadrao}`,
        tipo: "menuSuspenso",
        cor: infoArea.cor || "#666",
        subItens: {},
      };

      // Para cada categoria na área
      Object.keys(area.categorias).forEach((categoriaId) => {
        const categoriaData = area.categorias[categoriaId];
        const categoria = categoriaData.info;
        const modelos = categoriaData.modelos;

        if (modelos.length > 0) {
          // Se há apenas 1 categoria na área, adiciona os modelos diretamente
          if (Object.keys(area.categorias).length === 1) {
            modelos.forEach((modelo) => {
              if (modelo.tipoDinamico && modelo.arquivo) {
                dropdowns[`area_${areaId}`].subItens[modelo.chave] = {
                  nome: modelo.nome,
                  acao: async function () {
                    window.JirayaTemplateCustomizada.abrirModalTemplateCustomizada(
                      chrome.runtime.getURL("modelos/" + modelo.arquivo),
                      function(respostas, campos) {
                        const template = window.JirayaTemplateCustomizada.gerarTemplateCustomizada(respostas, campos);
                        inserirTemplate(template, idAleatorio);
                      }
                    );
                  },
                };
              } else {
                dropdowns[`area_${areaId}`].subItens[modelo.chave] = {
                  nome: modelo.nome,
                  acao: async function () {
                    const conteudo = await motorTemplatesJiraya.processarModelo(
                      modelo.chave
                    );
                    inserirTemplate(conteudo, idAleatorio);
                  },
                };
              }
            });
          } else {
            // Se há múltiplas categorias, cria submenu para categoria
            dropdowns[`area_${areaId}`].subItens[`categoria_${categoriaId}`] = {
              nome: categoria.nome,
              tipo: "menuSuspenso",
              subItens: {},
            };

            modelos.forEach((modelo) => {
              // Integração especial para checklistValidacao
              if (modelo.tipoDinamico && modelo.arquivo) {
                dropdowns[`area_${areaId}`].subItens[
                  `categoria_${categoriaId}`
                ].subItens[modelo.chave] = {
                  nome: modelo.nome,
                  acao: async function () {
                    window.JirayaTemplateCustomizada.abrirModalTemplateCustomizada(
                      chrome.runtime.getURL("modelos/" + modelo.arquivo),
                      function(respostas, campos) {
                        const template = window.JirayaTemplateCustomizada.gerarTemplateCustomizada(respostas, campos);
                        inserirTemplate(template, idAleatorio);
                      }
                    );
                  },
                };
              } else {
                dropdowns[`area_${areaId}`].subItens[
                  `categoria_${categoriaId}`
                ].subItens[modelo.chave] = {
                  nome: modelo.nome,
                  acao: async function () {
                    const conteudo = await motorTemplatesJiraya.processarModelo(
                      modelo.chave
                    );
                    inserirTemplate(conteudo, idAleatorio);
                  },
                };
              }
            });
          }
        }
      });
    }
  });

  jirayalog("Botões diretos criados:", Object.keys(botoesDiretos).length);
  jirayalog("Dropdowns de área criados:", Object.keys(dropdowns).length);

  // Se não há itens, cria menu de fallback para testar
  if (
    Object.keys(botoesDiretos).length === 0 &&
    Object.keys(dropdowns).length === 0
  ) {
    jirayalog("Nenhum item encontrado, criando fallback");
  }

  return { botoesDiretos, dropdowns };
}

/**
 * Cria um botão direto (sem dropdown) para execução imediata
 */
function criarBotaoDireto(opt = {}) {
  const { nome, cor, acao, elementoPai, idRandom } = opt;

  jirayalog("Criando botão direto:", nome);

  const botaoDireto = $("<a>")
    .attr("href", "#")
    .addClass("aui-button aui-button-subtle jiraya-botao-direto")
    .attr("data-jiraya-id", idRandom)
    .html(nome)
    // .css({
    //   "background-color": cor || "#666",
    //   "color": "white",
    //   "border-color": cor || "#666",
    //   "margin-right": "4px",
    //   "border-radius": "3px",
    //   "font-size": "12px",
    //   "font-weight": "500"
    // })
    .on("click", function (e) {
      e.preventDefault();
      e.stopPropagation();

      // Verifica se o botão está desabilitado
      if (
        $(this).attr("aria-disabled") === "true" ||
        $(this).hasClass("aui-button-disabled")
      ) {
        jirayalog("Botão direto desabilitado - não executando ação:", nome);
        return;
      }

      jirayalog("Botão direto clicado:", nome);

      if (acao && typeof acao === "function") {
        try {
          acao();
          jirayalog("Ação do botão direto executada:", nome);
        } catch (erro) {
          jirayalog("Erro ao executar ação do botão direto:", erro);
        }
      }
    })
    .on("mouseenter", function () {})
    .on("mouseleave", function () {});

  elementoPai.append(botaoDireto);

  // Sincroniza estado com menus suspensos do mesmo container
  setTimeout(() => {
    sincronizarEstadoBotoes(elementoPai);
  }, 100);

  jirayalog("Botão direto criado e adicionado:", nome);
}

/**
 * Sincroniza o estado (habilitado/desabilitado) entre menus suspensos e botões diretos
 * @param {jQuery} container - Container que contém os elementos
 */
function sincronizarEstadoBotoes(container) {
  const menuSuspenso = container.find(".aui-dropdown2-trigger");
  const botoesDiretos = container.find(".jiraya-botao-direto");

  if (menuSuspenso.length > 0 && botoesDiretos.length > 0) {
    // Observa mudanças no estado do menu suspenso
    const observer = new MutationObserver(function (mutations) {
      mutations.forEach(function (mutation) {
        if (
          mutation.type === "attributes" &&
          (mutation.attributeName === "aria-disabled" ||
            mutation.attributeName === "class")
        ) {
          const menuDesabilitado =
            menuSuspenso.attr("aria-disabled") === "true" ||
            menuSuspenso.hasClass("aui-button-disabled");

          botoesDiretos.each(function () {
            const botao = $(this);
            if (menuDesabilitado) {
              botao
                .attr("aria-disabled", "true")
                .addClass("aui-button-disabled")
                .css("pointer-events", "none");
            } else {
              botao
                .removeAttr("aria-disabled")
                .removeClass("aui-button-disabled")
                .css("pointer-events", "auto");
            }
          });

          jirayalog(
            "Estado dos botões sincronizado:",
            menuDesabilitado ? "desabilitado" : "habilitado"
          );
        }
      });
    });

    // Observa o menu suspenso
    observer.observe(menuSuspenso[0], {
      attributes: true,
      attributeFilter: ["aria-disabled", "class"],
    });

    // Aplica o estado inicial
    const menuDesabilitado =
      menuSuspenso.attr("aria-disabled") === "true" ||
      menuSuspenso.hasClass("aui-button-disabled");

    if (menuDesabilitado) {
      botoesDiretos.each(function () {
        $(this)
          .attr("aria-disabled", "true")
          .addClass("aui-button-disabled")
          .css("pointer-events", "none");
      });
    }
  }
}

// Manter função original para compatibilidade
async function criarMenuModelosDinamico(idAleatorio) {
  const resultado = await criarMenuAreasDinamico(idAleatorio);
  // Retorna no formato antigo para compatibilidade
  return { ...resultado.dropdowns, ...resultado.botoesDiretos };
}

/**
 * Cria menu específico por referência para campos da modal
 */
async function criarMenuPorReferencia(
  referencia,
  textareaElemento,
  idAleatorio
) {
  try {
    jirayalog("Criando menu para referência:", referencia);

    await garantirMotorInicializado();

    const areasReferencia =
      motorTemplatesJiraya.obterAreasPorReferencia(referencia);
    jirayalog(
      "Áreas encontradas para referência:",
      referencia,
      Object.keys(areasReferencia)
    );

    if (Object.keys(areasReferencia).length === 0) {
      jirayalog("Nenhuma área encontrada para referência:", referencia);
      return;
    }

    const elementoPai = $(
      `.barra-jiraya-editor-body[data-jiraya-id=${idAleatorio}]`
    );

    // Processa cada área da referência (igual à lógica do criarMenuAreasDinamico)
    Object.keys(areasReferencia).forEach((areaId) => {
      const area = areasReferencia[areaId];
      const infoArea = area.info;
      const temModelosDiretos =
        area.modelosDiretos && area.modelosDiretos.length > 0;
      const temCategorias = Object.keys(area.categorias).length > 0;

      jirayalog(
        `Área '${areaId}' - Modelos diretos: ${temModelosDiretos}, Categorias: ${temCategorias}`
      );

      // MODELOS DIRETOS - cria botões individuais (não dropdown)
      if (temModelosDiretos) {
        area.modelosDiretos.forEach((modelo) => {
          jirayalog("Criando botão direto para modelo:", modelo.nome);

          criarBotaoDiretoTextarea({
            nome: modelo.nome,
            cor: infoArea.cor || "#666",
            acao: async function () {
              const conteudo = await motorTemplatesJiraya.processarModelo(
                modelo.chave
              );
              inserirTemplateTextarea(conteudo, textareaElemento);
            },
            elementoPai: elementoPai,
            idRandom: `${idAleatorio}_direto_${modelo.chave}`,
          });
        });
      }

      // CATEGORIAS - cria dropdown (só se NÃO tiver modelos diretos ou se tiver ambos)
      if (temCategorias && !temModelosDiretos) {
        const itens = {};

        Object.keys(area.categorias).forEach((categoriaId) => {
          const categoriaData = area.categorias[categoriaId];

          categoriaData.modelos.forEach((modelo) => {
            itens[modelo.chave] = {
              nome: modelo.nome,
              acao: async function () {
                const conteudo = await motorTemplatesJiraya.processarModelo(
                  modelo.chave
                );
                inserirTemplateTextarea(conteudo, textareaElemento);
              },
            };
          });
        });

        jirayalog(
          "Criando dropdown para área:",
          infoArea.nome,
          "com itens:",
          Object.keys(itens)
        );

        // Cria o menu suspenso
        menuSuspenso({
          tituloBotaoMenu: infoArea.nome,
          idRandom: `${idAleatorio}_${areaId}`,
          elementoPai: elementoPai,
          itens: itens,
          cor: infoArea.cor,
        });
      }
    });
  } catch (erro) {
    jirayalog("Erro ao criar menu por referência:", erro);
  }
}

/**
 * Cria um botão direto para textarea (específico para modais)
 */
function criarBotaoDiretoTextarea(opt = {}) {
  const { nome, cor, acao, elementoPai, idRandom } = opt;

  jirayalog("Criando botão direto para textarea:", nome);

  const botaoDireto = $("<a>")
    .attr("href", "#")
    .addClass("aui-button aui-button-subtle jiraya-botao-direto-textarea")
    .attr("data-jiraya-id", idRandom)
    .html(nome)
    .on("click", function (e) {
      e.preventDefault();
      e.stopPropagation();

      // Verifica se o botão está desabilitado
      if (
        $(this).attr("aria-disabled") === "true" ||
        $(this).hasClass("aui-button-disabled")
      ) {
        jirayalog(
          "Botão direto textarea desabilitado - não executando ação:",
          nome
        );
        return;
      }

      jirayalog("Botão direto textarea clicado:", nome);

      if (acao && typeof acao === "function") {
        try {
          acao();
          jirayalog("Ação do botão direto textarea executada:", nome);
        } catch (erro) {
          jirayalog("Erro ao executar ação do botão direto textarea:", erro);
        }
      }
    });

  elementoPai.append(botaoDireto);

  setTimeout(() => {
    sincronizarEstadoBotoes(elementoPai);
  }, 100);

  jirayalog("Botão direto textarea criado e adicionado:", nome);
}

function obterTextoSeguro(elemento, transformacao = null) {
  if (!elemento || elemento.length === 0) return "";
  const texto = elemento.text().trim();
  if (transformacao && typeof transformacao === "function") {
    try {
      return transformacao(texto);
    } catch (error) {
      jirayalog("Erro na transformação do texto:", error);
      return "";
    }
  }
  return texto;
}

function splitSeguro(texto, separador, indice) {
  if (!texto) return "";
  const partes = texto.split(separador);
  return partes.length > indice ? partes[indice].trim() : "";
}
